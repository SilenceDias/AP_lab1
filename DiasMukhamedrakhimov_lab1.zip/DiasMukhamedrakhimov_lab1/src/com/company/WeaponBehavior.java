package com.company;

public interface WeaponBehavior {
    void useWeapon();
}
