package com.company;


class AxeBehavior implements WeaponBehavior{
    @Override
    public void useWeapon() {
        System.out.println("axe blow");
    }
}
